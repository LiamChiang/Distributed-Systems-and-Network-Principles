import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class PeriodicCatchUpRunnable implements Runnable {

    private HashMap<ServerInfo, Date> serverStatus;

    public PeriodicCatchUpRunnable(HashMap<ServerInfo, Date> serverStatus) {
        this.serverStatus = serverStatus;
    }

    @Override
    public void run() {

    
        // broadcast HeartBeat message to all peers
        ArrayList<Thread> threadArrayList = new ArrayList<>();
        for (ServerInfo ip : serverStatus.keySet()) {
            
            Thread thread = new Thread(new BlockchainClientRunnable(ip, "cu"));
            threadArrayList.add(thread);
            thread.start();
        }

        for (Thread thread : threadArrayList) {
            try {
                thread.join();
            } catch (InterruptedException e) {
            }
        }

        // sleep for two seconds
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
        }
        
    }
}