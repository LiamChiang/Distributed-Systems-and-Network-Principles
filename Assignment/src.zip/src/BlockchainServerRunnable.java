import java.io.*;
import java.net.Socket;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;

public class BlockchainServerRunnable implements Runnable{

    private Socket clientSocket;
    private Blockchain blockchain;
    private HashMap<ServerInfo, Date> serverStatus;
    private String localIP = "";
    private String remoteIP = "";
    private int remotePort = 0;
    private int localPort = 0;

    public BlockchainServerRunnable(Socket clientSocket, Blockchain blockchain, HashMap<ServerInfo, Date> serverStatus) {
        this.clientSocket = clientSocket;
        this.blockchain = blockchain;
        this.serverStatus = serverStatus;
    }

    public void run() {
        try {
            serverHandler(clientSocket.getInputStream(), clientSocket.getOutputStream());
            clientSocket.close();
        } catch (IOException e) {
        }
    }

    public void serverHandler(InputStream clientInputStream, OutputStream clientOutputStream) {

        localIP = (((InetSocketAddress) clientSocket.getLocalSocketAddress()).getAddress()).toString().replace("/", "");
        remoteIP = (((InetSocketAddress) clientSocket.getRemoteSocketAddress()).getAddress()).toString().replace("/", "");
        remotePort = ((InetSocketAddress) clientSocket.getRemoteSocketAddress()).getPort();
        localPort = ((InetSocketAddress) clientSocket.getLocalSocketAddress()).getPort();

        BufferedReader inputReader = new BufferedReader(
                new InputStreamReader(clientInputStream));
        PrintWriter outWriter = new PrintWriter(clientOutputStream, true);

        try {
            while (true) {
                String inputLine = inputReader.readLine();
                if (inputLine == null) {
                    break;
                }

                String[] tokens = inputLine.split("\\|");
                switch (tokens[0]) {
                    case "tx":
                        if (blockchain.addTransaction(inputLine))
                            outWriter.print("Accepted\n\n");
                        else
                            outWriter.print("Rejected\n\n");
                        outWriter.flush();
                        break;
                    case "pb":
                        outWriter.print(blockchain.toString() + "\n");
                        outWriter.flush();
                        break;
                    case "hb":
                        
                        serverStatus.put(new ServerInfo(remoteIP, Integer.parseInt(tokens[1])), new Date());
                        if (tokens[2].equals("0")) {

                            ArrayList<Thread> threadArrayList = new ArrayList<>();

                            for (ServerInfo ip : serverStatus.keySet()) {
                                if( ip.equals(new ServerInfo(remoteIP, Integer.parseInt(tokens[1]))) 
                                    || ip.equals(new ServerInfo(localIP, localPort)) ){
                                    continue;
                                }
                                
                                Thread thread = new Thread(new BlockchainClientRunnable(ip, "si|"+localPort+"|"+remoteIP+"|"+tokens[1]));

                                threadArrayList.add(thread);
                                thread.start();
                            }
                            for (Thread thread : threadArrayList) {    
                                thread.join();
                            }
                        }
                        break;

                    case "si":
                        if(!serverStatus.keySet().contains(new ServerInfo(tokens[2], Integer.parseInt(tokens[3])))){
                            serverStatus.put(new ServerInfo(tokens[2], Integer.parseInt(tokens[3])), new Date());

                            //relay
                            ArrayList<Thread> threadArrayList = new ArrayList<>();
                            
                            for (ServerInfo ip : serverStatus.keySet()) {
                                // if (ip.equals(new ServerInfo(tokens[2],Integer.parseInt(tokens[3])))==true||ip.equals(new ServerInfo(remoteIP,remotePort))==true) {
                                //     continue;
                                // }
                                if(ip.equals(new ServerInfo(remoteIP, Integer.parseInt(tokens[1]))) 
                                    || ip.equals(new ServerInfo(localIP, localPort)) 
                                    || ip.equals(new ServerInfo(tokens[2], Integer.parseInt(tokens[3]))) ){
                                    continue;
                                }
                                Thread thread = new Thread(new BlockchainClientRunnable(ip, "si|"+localPort+"|"+tokens[2]+"|"+tokens[3]));
                                threadArrayList.add(thread);
                                thread.start();
                            }
                            for (Thread thread : threadArrayList) {
                                thread.join();
                            } 
                        }
                        break;
                    case "lb":
                        // System.out.println("blochain's length: " + this.blockchain.getLength());
                        // System.out.println("lb|"+ tokens[1] + "|" + tokens[2] + "|" + tokens[3]);
                        // System.out.println(tokens[2] + " from " + tokens[1]);

                        if(this.blockchain.getLength() == 0){
                            // System.out.println("sending cu");
                            ArrayList<Thread> threadArrayList = new ArrayList<>();
                            for (ServerInfo ip : serverStatus.keySet()) {

                                Thread thread = new Thread(new BlockchainClientRunnable(ip, "cu"));
                                threadArrayList.add(thread);
                                thread.start();

                            }
                            for (Thread thread : threadArrayList) {
                                thread.join();
                            } 
                        }
                        if(Integer.parseInt(tokens[2]) > this.blockchain.getLength() && this.blockchain.getLength() != 0){
                            // System.out.println("catch up");
                        }
                        break;
                    case "cu":
                        // System.out.println("catching");
                        break;
                    case "cc":
                        return;
                    default:
                        outWriter.print("Error\n\n");
                        outWriter.flush();
                }
            }
        } catch (IOException e) {
        } 
        catch (InterruptedException e) {
            }
    }
}
